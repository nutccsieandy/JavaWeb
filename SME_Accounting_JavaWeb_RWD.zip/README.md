# SME Accounting 中小企業記帳系統

Java Web 前後台整合記帳系統，採 Spring Boot 3、Thymeleaf、Spring Security、JPA、MySQL/H2 與 Bootstrap 5 RWD。

## 功能
- 前台：營運儀表板、收入支出記帳、帳戶管理、日期區間報表
- 後台：使用者與角色管理、收入/支出分類管理
- 權限：ADMIN、STAFF
- RWD：手機、平板、桌機自適應
- 部署：本機 H2 或 Docker Compose + MySQL

## 本機執行
需求：JDK 21、Maven 3.9+

```bash
mvn spring-boot:run
```

開啟：http://localhost:8080

預設帳號：
- admin / admin123
- staff / staff123

## Docker + MySQL
```bash
docker compose up --build
```

開啟：http://localhost:8080

## 專案結構
- `controller`：前台與後台控制器
- `entity`：使用者、帳戶、分類、交易
- `repository`：JPA 資料存取
- `templates`：Thymeleaf RWD 頁面
- `/admin`：後台管理區

## 正式環境建議
首次登入後應立即修改預設帳號密碼，並透過反向代理啟用 HTTPS。可再擴充發票、應收應付、庫存、稅務與匯出 Excel/PDF。
