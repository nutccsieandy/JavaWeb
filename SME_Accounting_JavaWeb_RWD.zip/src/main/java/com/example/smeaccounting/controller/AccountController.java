package com.example.smeaccounting.controller;
import com.example.smeaccounting.entity.Account;
import com.example.smeaccounting.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
@Controller @RequiredArgsConstructor @RequestMapping("/accounts")
public class AccountController {
 private final AccountRepository repo;
 @GetMapping String list(Model m){m.addAttribute("accounts",repo.findAll());m.addAttribute("account",new Account(null,"",null,null,BigDecimal.ZERO,true));return "accounts/list";}
 @PostMapping("/save") String save(@ModelAttribute Account a){repo.save(a);return "redirect:/accounts";}
}
