package com.example.smeaccounting.controller;
import com.example.smeaccounting.entity.TransactionType;
import com.example.smeaccounting.repository.BookTransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.time.LocalDate;
@Controller @RequiredArgsConstructor
public class ReportController {
 private final BookTransactionRepository repo;
 @GetMapping("/reports") String report(@RequestParam(required=false) @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate start,@RequestParam(required=false) @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate end,Model m){
  if(start==null) start=LocalDate.now().withDayOfMonth(1); if(end==null) end=LocalDate.now();
  var income=repo.sumByTypeAndPeriod(TransactionType.INCOME,start,end); var expense=repo.sumByTypeAndPeriod(TransactionType.EXPENSE,start,end);
  m.addAttribute("start",start);m.addAttribute("end",end);m.addAttribute("income",income);m.addAttribute("expense",expense);m.addAttribute("profit",income.subtract(expense));m.addAttribute("transactions",repo.findByTransactionDateBetweenOrderByTransactionDateDesc(start,end));return "reports/index";
 }
}
