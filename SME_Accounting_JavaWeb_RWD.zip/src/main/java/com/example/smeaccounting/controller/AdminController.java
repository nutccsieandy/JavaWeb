package com.example.smeaccounting.controller;
import com.example.smeaccounting.entity.*;
import com.example.smeaccounting.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller @RequiredArgsConstructor @RequestMapping("/admin")
public class AdminController {
 private final AppUserRepository users; private final CategoryRepository categories; private final PasswordEncoder encoder;
 @GetMapping String home(Model m){m.addAttribute("userCount",users.count());m.addAttribute("categoryCount",categories.count());return "admin/index";}
 @GetMapping("/users") String users(Model m){m.addAttribute("users",users.findAll());m.addAttribute("newUser",new AppUser());m.addAttribute("roles",Role.values());return "admin/users";}
 @PostMapping("/users") String addUser(@ModelAttribute AppUser u){u.setPassword(encoder.encode(u.getPassword()));u.setEnabled(true);users.save(u);return "redirect:/admin/users";}
 @GetMapping("/categories") String categories(Model m){m.addAttribute("categories",categories.findAll());m.addAttribute("category",new Category());m.addAttribute("types",TransactionType.values());return "admin/categories";}
 @PostMapping("/categories") String addCategory(@ModelAttribute Category c){c.setActive(true);categories.save(c);return "redirect:/admin/categories";}
}
