package com.example.smeaccounting.controller;
import com.example.smeaccounting.entity.*;
import com.example.smeaccounting.repository.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
@Controller @RequiredArgsConstructor @RequestMapping("/transactions")
public class TransactionController {
 private final BookTransactionRepository repo; private final CategoryRepository categories; private final AccountRepository accounts;
 @GetMapping String list(Model m){m.addAttribute("transactions",repo.findAll()); return "transactions/list";}
 @GetMapping("/new") String form(Model m){ var t=new BookTransaction(); t.setTransactionDate(LocalDate.now()); t.setType(TransactionType.EXPENSE); populate(m,t); return "transactions/form"; }
 @GetMapping("/{id}/edit") String edit(@PathVariable Long id,Model m){populate(m,repo.findById(id).orElseThrow()); return "transactions/form";}
 @PostMapping("/save") String save(@Valid @ModelAttribute("transaction") BookTransaction t, BindingResult br, Model m){ if(br.hasErrors()){populate(m,t); return "transactions/form";} repo.save(t); return "redirect:/transactions";}
 @PostMapping("/{id}/delete") String delete(@PathVariable Long id){repo.deleteById(id); return "redirect:/transactions";}
 private void populate(Model m, BookTransaction t){m.addAttribute("transaction",t);m.addAttribute("categories",categories.findAll());m.addAttribute("accounts",accounts.findAll());m.addAttribute("types",TransactionType.values());}
}
