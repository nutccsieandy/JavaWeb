package com.example.smeaccounting.controller;
import com.example.smeaccounting.entity.TransactionType;
import com.example.smeaccounting.repository.BookTransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.time.LocalDate;
@Controller @RequiredArgsConstructor
public class MainController {
 private final BookTransactionRepository transactions;
 @GetMapping("/") String root(){return "redirect:/dashboard";}
 @GetMapping("/login") String login(){return "login";}
 @GetMapping("/dashboard") String dashboard(Model model){
  var now=LocalDate.now(); var start=now.withDayOfMonth(1);
  var income=transactions.sumByTypeAndPeriod(TransactionType.INCOME,start,now);
  var expense=transactions.sumByTypeAndPeriod(TransactionType.EXPENSE,start,now);
  model.addAttribute("income",income); model.addAttribute("expense",expense); model.addAttribute("profit",income.subtract(expense)); model.addAttribute("recent",transactions.findTop10ByOrderByTransactionDateDescIdDesc()); return "dashboard";
 }
}
