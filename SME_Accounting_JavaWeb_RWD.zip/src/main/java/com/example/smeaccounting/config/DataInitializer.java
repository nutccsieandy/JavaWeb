package com.example.smeaccounting.config;
import com.example.smeaccounting.entity.*;
import com.example.smeaccounting.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
@Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
 private final AppUserRepository users; private final AccountRepository accounts; private final CategoryRepository categories; private final PasswordEncoder encoder;
 public void run(String... args){
  if(users.count()==0){
   users.save(AppUser.builder().username("admin").password(encoder.encode("admin123")).displayName("系統管理員").role(Role.ADMIN).enabled(true).build());
   users.save(AppUser.builder().username("staff").password(encoder.encode("staff123")).displayName("會計人員").role(Role.STAFF).enabled(true).build());
  }
  if(accounts.count()==0){ accounts.save(Account.builder().name("現金").openingBalance(BigDecimal.ZERO).active(true).build()); accounts.save(Account.builder().name("公司銀行帳戶").bankName("範例銀行").openingBalance(BigDecimal.ZERO).active(true).build()); }
  if(categories.count()==0){
   for(String n:new String[]{"商品銷售","服務收入","其他收入"}) categories.save(Category.builder().name(n).type(TransactionType.INCOME).active(true).build());
   for(String n:new String[]{"進貨成本","薪資支出","租金","水電費","交通費","行銷費","其他支出"}) categories.save(Category.builder().name(n).type(TransactionType.EXPENSE).active(true).build());
  }
 }
}
