package com.example.smeaccounting.config;
import com.example.smeaccounting.service.UserDetailsServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.*;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
@Configuration @RequiredArgsConstructor
public class SecurityConfig {
 private final UserDetailsServiceImpl userDetailsService;
 @Bean PasswordEncoder passwordEncoder(){ return new BCryptPasswordEncoder(); }
 @Bean DaoAuthenticationProvider provider(){ var p=new DaoAuthenticationProvider(); p.setUserDetailsService(userDetailsService); p.setPasswordEncoder(passwordEncoder()); return p; }
 @Bean SecurityFilterChain filter(HttpSecurity http) throws Exception {
  http.authorizeHttpRequests(a->a.requestMatchers("/webjars/**","/css/**","/js/**","/login","/h2-console/**").permitAll()
    .requestMatchers("/admin/**").hasRole("ADMIN").anyRequest().authenticated())
    .formLogin(f->f.loginPage("/login").defaultSuccessUrl("/dashboard",true).permitAll())
    .logout(l->l.logoutSuccessUrl("/login?logout"));
  http.headers(h->h.frameOptions(f->f.sameOrigin()));
  http.csrf(c->c.ignoringRequestMatchers("/h2-console/**"));
  return http.build();
 }
}
