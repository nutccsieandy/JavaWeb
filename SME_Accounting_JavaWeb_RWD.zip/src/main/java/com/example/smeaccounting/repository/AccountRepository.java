package com.example.smeaccounting.repository;
import com.example.smeaccounting.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AccountRepository extends JpaRepository<Account,Long>{}
