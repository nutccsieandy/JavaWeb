package com.example.smeaccounting.repository;
import com.example.smeaccounting.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface CategoryRepository extends JpaRepository<Category,Long>{ List<Category> findByTypeAndActiveTrue(TransactionType type); }
