package com.example.smeaccounting.repository;
import com.example.smeaccounting.entity.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
public interface BookTransactionRepository extends JpaRepository<BookTransaction,Long>{
 List<BookTransaction> findTop10ByOrderByTransactionDateDescIdDesc();
 List<BookTransaction> findByTransactionDateBetweenOrderByTransactionDateDesc(LocalDate start, LocalDate end);
 @Query("select coalesce(sum(t.amount),0) from BookTransaction t where t.type=:type and t.transactionDate between :start and :end")
 BigDecimal sumByTypeAndPeriod(@Param("type") TransactionType type,@Param("start") LocalDate start,@Param("end") LocalDate end);
}
