package com.example.smeaccounting;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SmeAccountingApplication {
  public static void main(String[] args) { SpringApplication.run(SmeAccountingApplication.class, args); }
}
