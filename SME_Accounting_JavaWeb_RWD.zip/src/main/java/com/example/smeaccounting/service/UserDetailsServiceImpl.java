package com.example.smeaccounting.service;
import com.example.smeaccounting.entity.AppUser;
import com.example.smeaccounting.repository.AppUserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {
 private final AppUserRepository repo;
 public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
  AppUser u=repo.findByUsername(username).orElseThrow(()->new UsernameNotFoundException("找不到使用者"));
  return User.withUsername(u.getUsername()).password(u.getPassword()).roles(u.getRole().name()).disabled(!u.isEnabled()).build();
 }
}
