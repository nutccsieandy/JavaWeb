package com.example.smeaccounting.entity;
import jakarta.persistence.*;
import lombok.*;
@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Table(name="app_users")
public class AppUser {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,unique=true) private String username;
 @Column(nullable=false) private String password;
 @Column(nullable=false) private String displayName;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private Role role;
 private boolean enabled;
}
