package com.example.smeaccounting.entity;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Table(name="accounts")
public class Account {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String name;
 private String bankName;
 private String accountNo;
 @Column(nullable=false,precision=14,scale=2) private BigDecimal openingBalance;
 private boolean active;
}
