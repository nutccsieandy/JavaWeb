package com.example.smeaccounting.entity;
public enum Role { ADMIN, STAFF }
