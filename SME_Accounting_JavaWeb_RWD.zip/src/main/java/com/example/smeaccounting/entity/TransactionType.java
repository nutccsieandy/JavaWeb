package com.example.smeaccounting.entity;
public enum TransactionType { INCOME, EXPENSE }
