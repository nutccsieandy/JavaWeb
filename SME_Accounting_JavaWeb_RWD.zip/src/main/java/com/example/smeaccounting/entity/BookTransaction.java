package com.example.smeaccounting.entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Table(name="book_transactions")
public class BookTransaction {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotNull @DateTimeFormat(pattern="yyyy-MM-dd") @Column(nullable=false) private LocalDate transactionDate;
 @NotNull @Enumerated(EnumType.STRING) @Column(nullable=false) private TransactionType type;
 @NotNull @ManyToOne(optional=false) private Category category;
 @NotNull @ManyToOne(optional=false) private Account account;
 @NotBlank @Column(nullable=false) private String description;
 @NotNull @DecimalMin("0.01") @Column(nullable=false,precision=14,scale=2) private BigDecimal amount;
 private String counterparty;
 private String receiptNo;
 private String note;
 @Column(nullable=false) private LocalDateTime createdAt;
 @PrePersist void prePersist(){ if(createdAt==null) createdAt=LocalDateTime.now(); }
}
